/*
*========================================================================================================
*
* File                : matkey.c
* Hardware Environment:	
* Build Environment   : AVR Studio 4.16 + Winavr 20090313
* Version             : V1.0
* By                  : Wu Ze
*
*                                  (c) Copyright 2005-2009, WaveShare
*                                       http://www.waveshare.net
*                                          All Rights Reserved
*
*========================================================================================================
*/
#define _DVK501_M128_EX_ 1
#include <avr/io.h>
#include <ws_matkey_port.h>
#include <ws_lcd_ST7920_port.h>

int main(void)
{
	uint8_t tmp1=0,tmp2=0;
	st7920LcdInit(); /*LCD��ʼ��*/
	showLine(0,0,lcd_buffer,"����ʽ��������");
	showLine(0,1,lcd_buffer,"��ֵ��");
	while(1)
	{
		tmp1=getKeyVal();
		if(tmp1!=tmp2)
		{
			if(tmp1==0xFF) showLine(6,1,lcd_buffer,"  ");
			else showLine(6,1,lcd_buffer,"%d2",tmp1);
			refreshLCD(lcd_buffer); /*ˢ��LCD*/
		}
		tmp2=tmp1;
	}
}
