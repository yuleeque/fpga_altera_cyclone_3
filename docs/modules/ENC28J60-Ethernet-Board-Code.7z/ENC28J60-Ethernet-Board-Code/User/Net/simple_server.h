#ifndef _TCPIP_H
#define _TCPIP_H


int simple_server(void);

#endif


