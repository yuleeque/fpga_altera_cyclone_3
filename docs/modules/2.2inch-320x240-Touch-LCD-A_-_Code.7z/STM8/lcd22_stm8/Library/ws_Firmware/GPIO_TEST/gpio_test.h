#ifndef _GPIO_TEST_H_
#define _GPIO_TEST_H_

//#include "gpio_test.c"

void GPIO_ALL_TEST(void);
void GPIOtest_Configuration(void);
void GPIO_test_single();
void GPIO_test_Px();
void GPIO_test_Py();


#endif /*_GPIO_H*/

